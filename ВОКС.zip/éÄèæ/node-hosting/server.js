const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const AdmZip = require('adm-zip');

const app = express();
const upload = multer({ dest: 'uploads/' });
// Вместо фиксированного PORT = 3000
const PORT = process.env.PORT || 3000; 

app.listen(PORT, () => {
    console.log(`🚀 Сервер запущен на порту ${PORT}`);
});
const SITES_DIR = path.join(__dirname, 'hosted_sites');

if (!fs.existsSync(SITES_DIR)) fs.mkdirSync(SITES_DIR);
if (!fs.existsSync('uploads')) fs.mkdirSync('uploads');

// 1. ЛОГИКА ОПРЕДЕЛЕНИЯ: ПАНЕЛЬ ИЛИ САЙТ ПОЛЬЗОВАТЕЛЯ
app.use((req, res, next) => {
    const host = req.headers.host || '';
    if (host === `localhost:${PORT}` || host === `127.0.0.1:${PORT}`) {
        return next();
    }

    const parts = host.split('.');
    if (parts.length > 1) {
        const subdomain = parts[0];
        const sitePath = path.join(SITES_DIR, subdomain);

        if (fs.existsSync(sitePath)) {
            return express.static(sitePath)(req, res, next);
        } else {
            return res.status(404).send('<h1>Hosting: Site not found</h1>');
        }
    }
    next();
});

app.use(express.json());

// 2. ГРАФИЧЕСКИЙ ИНТЕРФЕЙС (GUI)
app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html lang="ru">
        <head>
            <meta charset="UTF-8">
            <title>wOS Hosting Panel</title>
            <script src="https://cdn.tailwindcss.com"></script>
            <style>
                body { background: #f2f2f7; font-family: -apple-system, sans-serif; }
                .glass { background: rgba(255, 255, 255, 0.8); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border: 1px solid white; }
                .ios-btn { background: #007AFF; color: white; border-radius: 14px; font-weight: 600; transition: 0.2s; }
                .ios-btn:active { transform: scale(0.96); opacity: 0.9; }
                .ios-input { background: rgba(120, 120, 128, 0.12); border: none; border-radius: 12px; padding: 14px; outline: none; width: 100%; }
            </style>
        </head>
        <body class="flex items-center justify-center min-h-screen p-4">
            <div class="glass w-full max-w-[360px] rounded-[38px] p-8 shadow-2xl">
                <div class="text-center mb-8">
                    <h1 class="text-xl font-bold tracking-tight">Хостинг сайтов</h1>
                    <p class="text-gray-500 text-xs mt-1">Загрузите .zip или .html файл</p>
                </div>

                <div class="space-y-4">
                    <input id="sub" type="text" placeholder="Название сайта" class="ios-input">
                    
                    <label class="ios-input flex flex-col items-center justify-center border-2 border-dashed border-gray-300 cursor-pointer hover:bg-black/5 transition-colors">
                        <span id="fName" class="text-gray-400 text-sm italic text-center">Выбрать файл (.html / .zip)</span>
                        <input id="siteFile" type="file" accept=".zip,.html" class="hidden" onchange="document.getElementById('fName').innerText=this.files[0].name">
                    </label>

                    <button onclick="deploy()" class="ios-btn w-full py-4 shadow-lg shadow-blue-100">Опубликовать</button>
                </div>

                <div id="status" class="hidden mt-6 p-4 bg-white rounded-2xl text-center shadow-sm">
                    <p class="text-[10px] uppercase text-gray-400 font-bold mb-1 tracking-widest">Сайт готов</p>
                    <a id="link" href="#" target="_blank" class="text-blue-500 text-sm font-semibold break-all underline"></a>
                </div>
            </div>

            <script>
                async function deploy() {
                    const sub = document.getElementById('sub').value.trim();
                    const file = document.getElementById('siteFile').files[0];
                    if(!sub || !file) return alert('Заполните все поля!');

                    const fd = new FormData();
                    fd.append('sub', sub);
                    fd.append('file', file);

                    try {
                        const res = await fetch('/register', { method: 'POST', body: fd });
                        const data = await res.json();
                        if(data.success) {
                            const url = 'http://' + sub + '.localhost:' + ${PORT};
                            document.getElementById('status').classList.remove('hidden');
                            document.getElementById('link').innerText = url;
                            document.getElementById('link').href = url;
                        } else { alert(data.error); }
                    } catch(e) { alert('Ошибка сервера'); }
                }
            </script>
        </body>
        </html>
    `);
});

// 3. API РЕГИСТРАЦИИ (ZIP или HTML)
app.post('/register', upload.single('file'), (req, res) => {
    const { sub } = req.body;
    if (!sub || !req.file) return res.json({ success: false, error: 'Данные не получены' });

    const targetDir = path.join(SITES_DIR, sub);
    if (fs.existsSync(targetDir)) return res.json({ success: false, error: 'Имя занято' });

    try {
        fs.mkdirSync(targetDir, { recursive: true });

        // ПРОВЕРКА: Это ZIP или HTML?
        if (req.file.originalname.endsWith('.zip')) {
            const zip = new AdmZip(req.file.path);
            const hasIndex = zip.getEntries().some(e => e.entryName.toLowerCase() === 'index.html');
            
            if (!hasIndex) {
                fs.rmSync(targetDir, { recursive: true });
                fs.unlinkSync(req.file.path);
                return res.json({ success: false, error: 'В ZIP-архиве нет index.html!' });
            }
            zip.extractAllTo(targetDir, true);
        } else if (req.file.originalname.endsWith('.html')) {
            // Если это просто HTML, копируем его как index.html
            fs.copyFileSync(req.file.path, path.join(targetDir, 'index.html'));
        } else {
            fs.rmSync(targetDir, { recursive: true });
            fs.unlinkSync(req.file.path);
            return res.json({ success: false, error: 'Формат файла не поддерживается' });
        }

        fs.unlinkSync(req.file.path);
        res.json({ success: true });
    } catch (e) {
        if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
        res.json({ success: false, error: 'Ошибка при публикации' });
    }
});

app.listen(PORT, () => console.log(`🚀 ПАНЕЛЬ: http://localhost:${PORT}`));